---
company: "Facebook"
role: "Intern"
dateStart: "07/01/2019"
dateEnd: "12/31/2019"
---

Iure illo neque tempora, voluptatem est quaerat voluptas praesentium ipsa dolorem dignissimos nulla ratione distinctio quae maiores eligendi nostrum? Quibusdam, debitis voluptatum, lorem ipsum dolor. Sit amet consectetur adipisicing elit.